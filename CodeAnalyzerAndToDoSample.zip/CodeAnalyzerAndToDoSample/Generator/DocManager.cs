using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Xml;
using System.IO;
using System.Xml.Xsl;

namespace CodeModelGeneration
{
	public static class DocManager
	{
		private static Dictionary<Assembly, XmlDocument> docStore = new Dictionary<Assembly, XmlDocument>();

		private static XslCompiledTransform transformer = null;
		private static XsltArgumentList transformerArgs = null;

		public static void RegisterTransformer(string xsltfile)
		{
			XslCompiledTransform transformer = new XslCompiledTransform();
			using (XmlTextReader reader = new System.Xml.XmlTextReader(xsltfile))
			{
				reader.ProhibitDtd = false;
				transformer.Load(reader);
			}
			DocManager.transformer = transformer;
			DocManager.transformerArgs = new XsltArgumentList();
		}

		public static string GetDocumentationFor(MethodBase method)
		{
			// Get documentation document:
			XmlDocument doc = GetXmlDocument(method.DeclaringType.Assembly);
			if (doc == null) return null;

			// Find summary:
			string dockey = GetDocumentationKeyFor(method);
			XmlNode summary = doc.SelectSingleNode(String.Format("//doc/members/member[@name='{0}']", dockey));
			if (summary != null)
				return summary.InnerXml;
			else
				return null;
		}

		private static XmlDocument GetXmlDocument(Assembly asm)
		{
			if (!docStore.ContainsKey(asm))
			{
				XmlDocument doc = null;

				string filename = new FileInfo(new Uri(asm.CodeBase, true).AbsolutePath).FullName;
				filename = filename.Replace(new FileInfo(filename).Extension, ".xml");

                if (File.Exists(filename))
				{
					// Load document:
					doc = new XmlDocument();
					doc.Load(filename);

					// Transform if transformer was registered:
					if (DocManager.transformer != null)
					{
						using (Stream stream = new MemoryStream())
						{
							XmlWriter output = new XmlTextWriter(stream, Encoding.UTF8);
							transformer.Transform(doc, transformerArgs, output);
							output.Flush();
							stream.Seek(0, SeekOrigin.Begin);
							doc = new XmlDocument();
							doc.Load(stream);
						}
					}
				}

				docStore[asm] = doc;
			}

			return docStore[asm];
		}

		public static string GetDocumentationKeyFor(Type type)
		{
			StringBuilder sb = new StringBuilder();
			AppendTypeName(sb, type, true);
			return sb.ToString();
		}

		public static string GetDocumentationKeyFor(MethodBase method)
		{
			StringBuilder sb = new StringBuilder();
			AppendMethodName(sb, method, true);
			return sb.ToString();
		}

		private static void AppendTypeName(StringBuilder sb, Type type, bool writePrefix)
		{
			if (writePrefix) sb.Append("T:");

			if (!String.IsNullOrEmpty(type.Namespace))
			{
				sb.Append(type.Namespace);
				sb.Append(".");
			}

			if (type.IsGenericType)
			{
				int paramnumindex = type.Name.IndexOf('`');
				sb.Append(type.Name.Substring(0, paramnumindex));
				sb.Append("{");
				string sep = String.Empty;
				foreach (Type typeParam in type.GetGenericArguments())
				{
					sb.Append(sep);
					AppendTypeName(sb, typeParam, false);
					sep = ",";
				}
				sb.Append("}");
			}
			else
			{
				sb.Append(type.Name);
			}
		}

		private static void AppendMethodName(StringBuilder sb, MethodBase method, bool writePrefix)
		{
			if (writePrefix) sb.Append("M:");

			AppendTypeName(sb, method.DeclaringType, false);
			sb.Append(".");

			sb.Append(method.Name.Replace(".", "#"));
			sb.Append("(");

			string sep = String.Empty;
			foreach(ParameterInfo param in method.GetParameters())
			{
				sb.Append(sep);
				AppendTypeName(sb, param.ParameterType, false);
				sep = ",";
			}
			sb.Append(")");
		}
	}
}
