using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Arebis.CodeAnalysis.Static;
using System.Security.Permissions;

public static class HelperExtension
{
    public static IList<ModelMethod> Sorted(this IEnumerable<ModelMethod> methods)
	{
        List<ModelMethod> result = new List<ModelMethod>(methods);
		result.Sort(new MethodComparer());
		return result;
	}

    public static string DisplayString(this ModelMethod subject)
    {
        return subject.DeclaringType.Name + "." + subject.Name;
    }

    public static string ToFilename(this ModelMethod subject, string format)
	{
        string str = subject.Signature;
		str = str.Replace("<", "[");
        str = str.Replace(">", "]");
        str = str.Replace("*", "_");
        str = str.Replace("?", "_");
        str = str.Replace(":", "_");
        str = str.Replace(" ", "");
		return String.Format(format, str);
	}

    public static string ToLink(this ModelMethod subject, string format)
    {
        return subject.ToLink(format, null);
    }

    public static string ToLink(this ModelMethod subject, string format, object options)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("<a href=\"");
        sb.Append(subject.ToFilename(format));
        sb.Append("\"");
        foreach (PropertyDescriptor prop in TypeDescriptor.GetProperties(options))
            sb.AppendFormat(" {0}=\"{1}\"", prop.Name, prop.GetValue(options));
        sb.Append(">");
        sb.Append(subject.DisplayString());
        sb.Append("</a>");

        return sb.ToString();
    }

    public static string[] RequiredRoles(this ModelMethod subject)
    {
        List<string> roles = new List<string>();
        foreach (var item in Attribute.GetCustomAttributes(subject.MethodBase, typeof(PrincipalPermissionAttribute)))
            roles.Add(((PrincipalPermissionAttribute)item).Role);

        return roles.ToArray();
    }

    public static bool IsFullyImplemented(this ModelMethod subject)
    {
        return (subject.GetAllCallsMethods().WhereTagsContains("missingimplementationexception").Count() == 0);
    }
}

public class MethodComparer : System.Collections.Generic.IComparer<ModelMethod>
{
    int IComparer<ModelMethod>.Compare(ModelMethod left, ModelMethod right)
	{
		string leftname = (left.Name.Contains(".") ? left.Signature : left.DeclaringType.ToString() + "." + left.Signature);
		string rightname = (right.Name.Contains(".") ? right.Signature : right.DeclaringType.ToString() + "." + right.Signature);
		return leftname.CompareTo(rightname);
	}
}
