﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace ToDoSample.Application
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : global::System.Windows.Application
    {
        private void App_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            // Show error dialog:
            MessageBox.Show(this.MainWindow, String.Format("{0}\r\n\r\nPlease contact support.", ((Exception)e.Exception).Message), this.MainWindow.Title, MessageBoxButton.OK, MessageBoxImage.Error);
            
            // Prevent further handling:
            e.Handled = true;
        }
    }
}
