﻿using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace ToDoSample.Application.Infrastructure
{
    /// <summary>
    /// A common, generic WCF service agent.
    /// </summary>
    public class ServiceAgent<T> : IDisposable
        where T : class
    {
        private static Dictionary<string, ChannelFactory<T>> factoryCache = new Dictionary<string, ChannelFactory<T>>();

        private T channel;

        /// <summary>
        /// Initializes a new ServiceAgent instance.
        /// </summary>
        public ServiceAgent(string endpointConfigurationName)
            : this(GetChannelFactory(endpointConfigurationName))
        { }

        /// <summary>
        /// Initializes a new ServiceAgent instance.
        /// </summary>
        protected internal ServiceAgent(ChannelFactory<T> channelFactory)
        {
            this.channel = channelFactory.CreateChannel();
        }

        /// <summary>
        /// Gets a channel factory for the given endpointConfiguration.
        /// Channel factories made by endpointConfiguration are cached.
        /// </summary>
        internal static ChannelFactory<T> GetChannelFactory(string endpointConfigurationName)
        {
            lock (factoryCache)
            {

                ChannelFactory<T> result;
                if (!factoryCache.TryGetValue(endpointConfigurationName, out result))
                {
                    result
                        = factoryCache[endpointConfigurationName]
                        = new ChannelFactory<T>(endpointConfigurationName);
                }

                return result;
            }
        }

        /// <summary>
        /// The service agent invoker.
        /// </summary>
        public virtual T Invoke
        {
            get { return this.channel; }
        }

        /// <summary>
        /// Communication state of the channel.
        /// </summary>
        public CommunicationState ChannelState
        {
            get { return ((IClientChannel)this.channel).State; }
        }

        /// <summary>
        /// Disposes the service agent and closes the WCF channel.
        /// </summary>
        public virtual void Dispose()
        {
            if (this.channel != null)
            {
                try
                {
                    if (this.ChannelState == CommunicationState.Faulted)
                        ((IClientChannel)this.channel).Abort();
                    else
                        ((IClientChannel)this.channel).Close();
                }
                finally
                {
                    this.channel = null;
                }
            }
        }
    }
}
