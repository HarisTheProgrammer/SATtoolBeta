﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace ToDoSample.Application.Infrastructure
{
    /// <summary>
    /// Formats date values.
    /// </summary>
    // Inspired from: http://learnwpf.com/Posts/Post.aspx?postId=05229e33-fcd4-44d5-9982-a002f2250a64
    [ValueConversion(typeof(DateTime), typeof(string))]
    public class DateTimeFormatConverter : IValueConverter
    {
        public object Convert(object value, Type targetType,
            object parameter, System.Globalization.CultureInfo culture)
        {
            string formatString = parameter as string;
            if (value == null)
            {
                return null;
            }
            else if (formatString != null)
            {
                return ((DateTime)value).ToString(formatString, culture);
            }
            else
            {
                return ((DateTime)value).ToString(culture);
            }
        }

        public object ConvertBack(object value, Type targetType,
            object parameter, System.Globalization.CultureInfo culture)
        {
            string formatString = parameter as string;
            if (String.IsNullOrEmpty(value as string))
            {
                return null;
            }
            else if (formatString != null)
            {
                return DateTime.ParseExact((string)value, formatString, culture);
            }
            else
            {
                return DateTime.Parse((string)value, culture);
            }
        }
    }
}
