﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ToDoSample Application")]
[assembly: AssemblyCompany("Arebis")]
[assembly: AssemblyProduct("ToDoSample")]
[assembly: AssemblyCopyright("Copyright © Arebis 2010")]

[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
