﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ToDoSample.Contract;

namespace ToDoSample.Application
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static readonly DependencyProperty AllUsersProperty =
            DependencyProperty.Register("AllUsers", typeof(List<User>), typeof(MainWindow), new UIPropertyMetadata(default(List<User>)));
        public static readonly DependencyProperty CurrentUserProperty =
            DependencyProperty.Register("CurrentUser", typeof(User), typeof(MainWindow), new UIPropertyMetadata(default(User)));
        public static readonly DependencyProperty UserFilterProperty =
            DependencyProperty.Register("UserFilter", typeof(string), typeof(MainWindow), new UIPropertyMetadata(default(string)));
        public static readonly DependencyProperty ToDoItemsProperty =
            DependencyProperty.Register("ToDoItems", typeof(List<ToDoItem>), typeof(MainWindow), new UIPropertyMetadata(default(List<ToDoItem>)));
        public static readonly DependencyProperty CurrentToDoItemProperty =
            DependencyProperty.Register("CurrentToDoItem", typeof(ToDoItem), typeof(MainWindow), new UIPropertyMetadata(default(ToDoItem)));

        /// <summary>
        /// Constructor.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// AllUsers property.
        /// </summary>
        public List<User> AllUsers
        {
            get { return (List<User>)GetValue(AllUsersProperty); }
            set { SetValue(AllUsersProperty, value); }
        }

        /// <summary>
        /// CurrentUser property.
        /// </summary>
        public User CurrentUser
        {
            get { return (User)GetValue(CurrentUserProperty); }
            set { SetValue(CurrentUserProperty, value); }
        }

        /// <summary>
        /// UserFilter property.
        /// </summary>
        public string UserFilter
        {
            get { return (string)GetValue(UserFilterProperty); }
            set { SetValue(UserFilterProperty, value); }
        }

        /// <summary>
        /// ToDoItems property.
        /// </summary>
        public List<ToDoItem> ToDoItems
        {
            get { return (List<ToDoItem>)GetValue(ToDoItemsProperty); }
            set { SetValue(ToDoItemsProperty, value); }
        }

        /// <summary>
        /// CurrentToDoItem property.
        /// </summary>
        public ToDoItem CurrentToDoItem
        {
            get { return (ToDoItem)GetValue(CurrentToDoItemProperty); }
            set { SetValue(CurrentToDoItemProperty, value); }
        }

        public void WindowLoaded(object sender, RoutedEventArgs e)
        {
            // On application startup, load list of users:
            using (var service = new ToDoService())
            {
                this.AllUsers = service.Invoke.ListAllUsers();
            }
        }

        public void UserSelected(object sender, SelectionChangedEventArgs e)
        {
            this.RefreshToDoItems();
        }

        public void ToDoItemSelected(object sender, SelectionChangedEventArgs e)
        {
            if (this.todoListBox.SelectedItem != null)
                this.CurrentToDoItem = ((ToDoItem)this.todoListBox.SelectedItem).WorkingCopy();
        }

        public void MarkDoneClicked(object sender, RoutedEventArgs e)
        {
            using (var service = new ToDoService())
            {
                service.Invoke.MarkToDoItemDone(this.CurrentToDoItem.Id);
            }

            this.RefreshToDoItems();
        }

        public void CreateNewToDoItemClicked(object sender, RoutedEventArgs e)
        {
            this.CurrentToDoItem = null;
            this.CurrentToDoItem = new ToDoItem();
        }

        public void SaveClicked(object sender, RoutedEventArgs e)
        {
            ToDoItem item = null;

            using (var service = new ToDoService())
            {
                if (this.CurrentToDoItem.IsNewInstance())
                {
                    item = service.Invoke.CreateToDoItem(
                        this.CurrentUser.Id,
                        this.CurrentToDoItem.Text,
                        this.CurrentToDoItem.DueDate
                    );
                }
                else
                {
                    item = service.Invoke.UpdateToDoItem(
                        this.CurrentToDoItem.Id,
                        this.CurrentToDoItem.Text,
                        this.CurrentToDoItem.DueDate
                    );
                }
            }

            this.RefreshToDoItems();

            this.todoListBox.SelectedItem = item;
        }

        public void DeleteClicked(object sender, RoutedEventArgs e)
        {
            using (var service = new ToDoService())
            {
                service.Invoke.DeleteToDoItem(this.CurrentToDoItem.Id);
            }

            this.RefreshToDoItems();
        }

        private void RefreshToDoItems()
        {
            // When a user is selected, retrieve it's ToDo items:
            using (var service = new ToDoService())
            {
                this.ToDoItems = service.Invoke.ListToDoItemsForUser(this.CurrentUser.Id);
            }
        }
    }
}
