﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ToDoSample.Contract;
using ToDoSample.Application.Infrastructure;

namespace ToDoSample.Application
{
    internal class ToDoService : ServiceAgent<IToDoService>
    {
        public ToDoService()
            : base("ToDoServiceEndpoint")
        { }
    }
}
