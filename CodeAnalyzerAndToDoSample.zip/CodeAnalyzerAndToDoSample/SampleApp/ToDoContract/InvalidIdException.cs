﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ToDoSample.Contract
{
    [Serializable]
    public class InvalidIdException : ApplicationException
    {
        public InvalidIdException()
            : base()
        { }

        public InvalidIdException(string message)
            : base(message)
        { }

        protected InvalidIdException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        { }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
        }
    }
}
