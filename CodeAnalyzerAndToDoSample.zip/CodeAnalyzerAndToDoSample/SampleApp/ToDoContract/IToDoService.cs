﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ToDoSample.Contract
{
    [ServiceContract]
    public interface IToDoService
    {
        [OperationContract]
        List<User> ListAllUsers();

        [OperationContract]
        List<User> ListUsersMatching(string nameMatchString);

        [OperationContract]
        User GetUser(int id);

        [OperationContract]
        User FindUserByName(string name);

        [OperationContract]
        List<ToDoItem> ListToDoItemsForUser(int userId);

        [OperationContract]
        List<ToDoItem> ListDoneItemsForUser(int userId);

        [OperationContract]
        ToDoItem CreateToDoItem(int userId, string toDoText, DateTime? dueDate);

        [OperationContract]
        ToDoItem UpdateToDoItem(int itemId, string toDoText, DateTime? dueDate);

        [OperationContract]
        void MarkToDoItemDone(int itemId);

        [OperationContract]
        void DeleteToDoItem(int itemId);
    }
}
