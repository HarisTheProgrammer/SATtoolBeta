﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ToDoSample.Contract
{
    [DataContract]
    public class ToDoItem
    {
        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public int UserId { get; set; }

        [DataMember]
        public string Text { get; set; }

        [DataMember]
        public DateTime? DueDate { get; set; }

        [DataMember]
        public bool IsDone { get; set; }

        public bool IsNewInstance()
        {
            return (this.Id == default(int));
        }

        public override bool Equals(object obj)
        {
            ToDoItem other = obj as ToDoItem;
            if (Object.ReferenceEquals(other, null))
                return false;
            else if (this.Id == default(int))
                return Object.ReferenceEquals(this, other);
            else
                return (this.Id == other.Id);
        }

        public ToDoItem WorkingCopy()
        {
            return new ToDoItem() { 
                Id = this.Id,
                UserId = this.UserId,
                Text = this.Text,
                DueDate = this.DueDate,
                IsDone = this.IsDone
            };
        }
    }
}
