﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ToDoSample.Contract
{
    [DataContract]
    public class User
    {
        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public string Name { get; set; }

        public override bool Equals(object obj)
        {
            User other = obj as User;
            if (Object.ReferenceEquals(other, null))
                return false;
            else if (this.Id == default(int))
                return Object.ReferenceEquals(this, other);
            else
                return (this.Id == other.Id);
        }
    }
}
