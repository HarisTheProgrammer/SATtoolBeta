﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

using Contract = ToDoSample.Contract;
using System.Security.Permissions;

namespace ToDoSample.Service
{
    /// <summary>
    /// Implementation of the IToDoService.
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    internal class ToDoServiceImplementation : Contract.IToDoService
    {
        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.FamilyMember)]
        List<Contract.User> Contract.IToDoService.ListAllUsers()
        {
            return ToDoComponentManager.ListAllUsers()
                .ToContractType();
        }

        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.FamilyMember)]
        List<Contract.User> Contract.IToDoService.ListUsersMatching(string nameMatchString)
        {
            return ToDoComponentManager.ListUsersMatching(nameMatchString)
                .ToContractType();
        }

        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.Anyone)]
        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.FamilyMember)]
        Contract.User Contract.IToDoService.GetUser(int id)
        {
            return ToDoComponentManager.GetUser(id)
                .ToContractType();
        }

        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.Anyone)]
        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.FamilyMember)]
        Contract.User Contract.IToDoService.FindUserByName(string name)
        {
            return ToDoComponentManager.FindUserByName(name)
                .ToContractType();
        }

        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.FamilyMember)]
        List<Contract.ToDoItem> Contract.IToDoService.ListToDoItemsForUser(int userId)
        {
            return ToDoComponentManager.ListToDoItemsForUser(userId)
                .ToContractType();
        }

        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.FamilyMember)]
        List<Contract.ToDoItem> Contract.IToDoService.ListDoneItemsForUser(int userId)
        {
            return ToDoComponentManager.ListDoneItemsForUser(userId)
                .ToContractType();
        }

        [OperationBehavior(TransactionScopeRequired = true)]
        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.FamilyMember)]
        Contract.ToDoItem Contract.IToDoService.CreateToDoItem(int userId, string toDoText, DateTime? dueDate)
        {
            return ToDoComponentManager.CreateToDoItem(userId, toDoText, dueDate)
                .ToContractType();
        }

        [OperationBehavior(TransactionScopeRequired = true)]
        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.FamilyMember)]
        Contract.ToDoItem Contract.IToDoService.UpdateToDoItem(int itemId, string toDoText, DateTime? dueDate)
        {
            ToDoComponentManager.UpdateToDoItem(itemId, toDoText, dueDate);

            return ToDoComponentManager.GetToDoItem(itemId)
                .ToContractType();
        }

        [OperationBehavior(TransactionScopeRequired = true)]
        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.FamilyMember)]
        void Contract.IToDoService.MarkToDoItemDone(int itemId)
        {
            ToDoComponentManager.MarkToDoItemDone(itemId);
        }

        [OperationBehavior(TransactionScopeRequired = true)]
        [PrincipalPermission(SecurityAction.Demand, Role = Contract.SecurityRoles.FamilyHead)]
        void Contract.IToDoService.DeleteToDoItem(int itemId)
        {
            ToDoComponentManager.DeleteToDoItem(itemId);
        }
    }
}
