﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Contract = ToDoSample.Contract;

namespace ToDoSample.Service
{
    internal static class MappingExtensionsHelper
    {
        internal static Contract.User ToContractType(this User subject)
        {
            if (subject == null) 
                return null;
            else
                return new Contract.User()
                {
                    Id = subject.Id,
                    Name = subject.Name
                };
        }

        internal static List<Contract.User> ToContractType(this IEnumerable<User> subject)
        {
            List<Contract.User> result = new List<ToDoSample.Contract.User>();
            foreach (var item in subject)
                result.Add(item.ToContractType());
            return result;
        }

        internal static Contract.ToDoItem ToContractType(this ToDoItem subject)
        {
            if (subject == null)
                return null;
            else
                return new Contract.ToDoItem()
                {
                    Id = subject.Id,
                    UserId = subject.Owner.Id,
                    Text = subject.Text,
                    DueDate = subject.DueDate,
                    IsDone = subject.IsDone
                };
        }

        internal static List<Contract.ToDoItem> ToContractType(this IEnumerable<ToDoItem> subject)
        {
            List<Contract.ToDoItem> result = new List<ToDoSample.Contract.ToDoItem>();
            foreach (var item in subject)
                result.Add(item.ToContractType());
            return result;
        }
    }
}
