﻿
CREATE TABLE [Users](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED ([Id] ASC)
)
GO

CREATE TABLE [ToDos](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[ToDo] [nvarchar](200) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[DueDate] [datetime] NULL,
	[DoneDate] [datetime] NULL,
 CONSTRAINT [PK_ToDos] PRIMARY KEY CLUSTERED ([Id] ASC)
)
GO

ALTER TABLE [ToDos] ADD  CONSTRAINT [DF__ToDos__CreatedOn]  DEFAULT (getdate()) FOR [CreatedDate]
GO

ALTER TABLE [ToDos]  WITH CHECK ADD  CONSTRAINT [FK_ToDos_Users] FOREIGN KEY([UserId])
REFERENCES [Users] ([Id])
GO

ALTER TABLE [ToDos] CHECK CONSTRAINT [FK_ToDos_Users]
GO
