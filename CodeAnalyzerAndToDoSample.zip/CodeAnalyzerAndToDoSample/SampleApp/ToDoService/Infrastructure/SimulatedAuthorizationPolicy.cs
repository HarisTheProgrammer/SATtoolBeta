﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IdentityModel.Policy;
using System.IdentityModel.Claims;
using System.Security.Principal;
using System.Configuration;

namespace ToDoSample.Service.Infrastructure
{
    /// <summary>
    /// A custom AuthorizationPolicy that sets principal roles
    /// from the App.Config settings.
    /// </summary>
    // http://www.leastprivilege.com/CustomPrincipalsAndWCF.aspx
    public sealed class SimulatedAuthorizationPolicy : IAuthorizationPolicy
    {
        #region IAuthorizationPolicy Members

        public bool Evaluate(EvaluationContext evaluationContext, ref object state)
        {
            GenericIdentity identity = new GenericIdentity(ConfigurationManager.AppSettings["SimulatedSecurityUser"]);
            GenericPrincipal principal = new GenericPrincipal(identity, ConfigurationManager.AppSettings["SimulatedSecurityRoles"].Split(','));

            evaluationContext.Properties["Principal"] = principal;

            return true;
        }

        public ClaimSet Issuer
        {
            get { return ClaimSet.System; }
        }

        #endregion

        #region IAuthorizationComponent Members

        public string Id
        {
            get { return this.GetType().ToString(); }
        }

        #endregion
    }
}
