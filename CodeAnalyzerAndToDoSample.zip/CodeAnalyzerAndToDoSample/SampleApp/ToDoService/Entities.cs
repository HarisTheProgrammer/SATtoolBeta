﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToDoSample.Service
{
    partial class ToDoObjectContext
    {
    }

    partial class User
    {
    }

    partial class ToDoItem
    {
        public bool IsDone
        {
            get { return this.DoneDate.HasValue; }
        }
    }
}
