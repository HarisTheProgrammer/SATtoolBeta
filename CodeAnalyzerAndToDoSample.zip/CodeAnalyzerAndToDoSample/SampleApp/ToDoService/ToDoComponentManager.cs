﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToDoSample.Service
{
    internal static class ToDoComponentManager
    {
        /// <summary>
        /// Lists all users.
        /// </summary>
        internal static IEnumerable<User> ListAllUsers()
        {
            using (var context = new ToDoObjectContext())
            {
                // Return whole user set:
                return context.UserSet.ToList();
            }
        }

        /// <summary>
        /// Lists all users with names matching a given regular expression.
        /// </summary>
        /// <param name="nameMatchString">Regular expression to match user names to.</param>
        internal static IEnumerable<User> ListUsersMatching(string nameMatchString)
        {
            using (var context = new ToDoObjectContext())
            {
                // Return filtered user set:
                return FilterUsers(context.UserSet, nameMatchString).ToList();
            }

        }

        /// <summary>
        /// Returns the user with the given id.
        /// </summary>
        internal static User GetUser(int id)
        {
            using (var context = new ToDoObjectContext())
            {
                // Return selected user:
                return context.UserSet.Where(u => u.Id == id).FirstOrDefault();
            }
        }

        /// <summary>
        /// Returns users with the given name.
        /// </summary>
        internal static User FindUserByName(string name)
        {
            // Return the first user matching the full name:
            return ListUsersMatching(name).FirstOrDefault();
        }

        /// <summary>
        /// Lists all non-done ToDo items for the given user.
        /// </summary>
        internal static IEnumerable<ToDoItem> ListToDoItemsForUser(int userId)
        {
            using (var context = new ToDoObjectContext())
            {
                // Query for ToDoItems not yet done:
                var query = from item
                            in context.ToDoItemSet
                                .Include("Owner")
                            where item.Owner.Id == userId
                               && item.DoneDate == null
                            select item;

                // Return query result:
                return query.ToList();
            }
        }

        /// <summary>
        /// Lists all ToDo items.
        /// </summary>
        internal static IEnumerable<ToDoItem> ListAllToDoItems()
        {
            using (var context = new ToDoObjectContext())
            {
                // Return whole ToDoItem set:
                return context.ToDoItemSet.ToList();
            }
        }

        /// <summary>
        /// Lists all done ToDo items for the given user.
        /// </summary>
        internal static IEnumerable<ToDoItem> ListDoneItemsForUser(int userId)
        {
            using (var context = new ToDoObjectContext())
            {
                // Query for done ToDoItems:
                var query = from item
                            in context.ToDoItemSet
                                .Include("Owner")
                            where item.Owner.Id == userId
                               && item.DoneDate != null
                            select item;

                // Return query result:
                return query.ToList();
            }
        }

        /// <summary>
        /// Returns the ToDo item with the given id.
        /// </summary>
        internal static ToDoItem GetToDoItem(int id)
        {
            using (var context = new ToDoObjectContext())
            {
                // Return selected user:
                return context.ToDoItemSet
                    .Include("Owner")
                    .Where(t => t.Id == id)
                    .FirstOrDefault();
            }
        }

        /// <summary>
        /// Creates a new ToDo item.
        /// </summary>
        /// <param name="userId">The user's id to assign the ToDo to.</param>
        /// <param name="toDoText">The text or message of the ToDo.</param>
        /// <param name="dueDate">The due date of the ToDo.</param>
        /// <returns>The created ToDo item.</returns>
        internal static ToDoItem CreateToDoItem(int userId, string toDoText, DateTime? dueDate)
        {
            using (var context = new ToDoObjectContext())
            {
                context.Connection.Open();

                // Retrieve user/owner:
                User owner = context.UserSet.Where(u => u.Id == userId).FirstOrDefault();
                if (owner == null) throw new Contract.InvalidIdException();

                // Create ToDo item:
                ToDoItem newItem = new ToDoItem()
                {
                    CreatedDate = DateTime.Now,
                    Owner = owner,
                    Text = toDoText,
                    DueDate = dueDate
                };

                // Add to context:
                context.AddToToDoItemSet(newItem);

                // Save context changes:
                context.SaveChanges();

                // Return the created ToDo item:
                return newItem;
            }
        }

        /// <summary>
        /// Updates the text and due date of the ToDoItem with the given id.
        /// </summary>
        /// <param name="itemId">The id of the ToDo item to update.</param>
        /// <param name="toDoText">The new ToDoItem text.</param>
        /// <param name="dueDate">The new ToDoItem due date.</param>
        internal static void UpdateToDoItem(int itemId, string toDoText, DateTime? dueDate)
        {
            using (var context = new ToDoObjectContext())
            {
                context.Connection.Open();

                // Retrieve todo item:
                ToDoItem item = context.ToDoItemSet.Where(i => i.Id == itemId).FirstOrDefault();

                // Update item:
                item.Text = toDoText;
                item.DueDate = dueDate;

                // Save context changes:
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Marks the ToDo item with the given id as done.
        /// </summary>
        internal static void MarkToDoItemDone(int itemId)
        {
            using (var context = new ToDoObjectContext())
            {
                context.Connection.Open();

                // Retrieve todo item:
                ToDoItem item = context.ToDoItemSet.Where(i => i.Id == itemId).FirstOrDefault();
                if (item == null) throw new Contract.InvalidIdException();

                // Mark item done:
                item.DoneDate = DateTime.Now;

                // Save context changes:
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Deletes the ToDo item with the given id.
        /// </summary>
        internal static void DeleteToDoItem(int itemId)
        {
            using (var context = new ToDoObjectContext())
            {
                context.Connection.Open();

                // Retrieve todo item:
                ToDoItem item = context.ToDoItemSet.Where(i => i.Id == itemId).FirstOrDefault();
                if (item == null) throw new Contract.InvalidIdException();

                // Delete item:
                context.DeleteObject(item);

                // Save context changes:
                context.SaveChanges();
            }
        }

        #region Private implementation

        private static IEnumerable<User> FilterUsers(IEnumerable<User> users, string nameMatchString)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
