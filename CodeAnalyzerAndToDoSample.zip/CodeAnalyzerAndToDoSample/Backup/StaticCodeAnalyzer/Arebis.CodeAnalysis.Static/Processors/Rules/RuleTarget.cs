using System;
using System.Collections.Generic;
using System.Text;

namespace Arebis.CodeAnalysis.Static.Processors.Rules
{
	public enum RuleTarget
	{
		Method,
		Type,
		Assembly
	}
}
