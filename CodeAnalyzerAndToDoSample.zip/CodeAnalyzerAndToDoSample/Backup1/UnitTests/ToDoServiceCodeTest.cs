﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Arebis.CodeAnalysis.Static;
using ToDoSample.Service;
using System.Data.Objects;
using ToDoSample.Contract;
using System.ServiceModel;
using System.Reflection;

namespace ToDoSample.UnitTests
{
    [TestClass]
    public class ToDoServiceCodeTest
    {
        #region Build CodeModel

        private static CodeModel CodeModel;

        [ClassInitialize]
        public static void ClassInitialize(TestContext testContext)
        {
            // Build the CodeModel:
            StaticCodeAnalyzerSession session = new StaticCodeAnalyzerSession();
            session.AddAssembly(typeof(ToDoServiceImplementation).Assembly);
            session.AddAssembly(typeof(ObjectContext).Assembly);
            session.AnalyzerFilter = new AnalyzerFilter();
            CodeModel = new StaticCodeAnalyzer().Process(session);

            // Mark service methods:
            var qsrv = from m in CodeModel.Methods
                       where m.ImplementedInterfaceMethods.Select(im => im.DeclaringType == typeof(IToDoService)).Count() > 0
                       select m;
            foreach (var method in qsrv)
                method.Tags.Add("serviceimplementation");

            // Mark entity framework save methods:
            var qefs = from m in CodeModel.Methods
                       where m.Name == "SaveChanges"
                          && m.DeclaringType == typeof(ObjectContext)
                       select m;
            foreach (var method in qefs)
                method.Tags.Add("savechanges");
        }

        internal class AnalyzerFilter : IAnalyzerFilter
        {
            #region IAnalyzerFilter Members

            public bool ProcessAssembly(Assembly assembly)
            {
                return true;
            }

            public bool ProcessType(Type type)
            {
                // Skip all types in System.* namespaces except ObjectContext:
                if (type.Namespace == null || (type.Namespace.StartsWith("System.") && (type.Name != "ObjectContext")))
                    return false;
                else
                    return true;
            }

            public bool ProcessMethod(MethodBase method)
            {
                return true;
            }

            #endregion
        }

        #endregion

        /// <summary>
        /// Verifies that all service operations that perform a database mutation (insert/update/delete)
        /// have the [OperationBehavior(TransactionScopeRequired = true)] attribute set.
        /// </summary>
        [TestMethod]
        public void TransactionCodeTest()
        {
            bool hasErrors = false;

            // For all service implementation methods:
            foreach (ModelMethod m in CodeModel.Methods.WhereTagsContains("serviceimplementation"))
            {
                // If the method calls ObjectContext.SaveChanges:
                if (m.GetAllCallsMethods().WhereTagsContains("savechanges").Count() > 0)
                {
                    // Check if it has the [OperationBehavior(TransactionScopeRequired = true)] attribute set.
                    bool hasTransactionScopeRequired = false;
                    foreach (OperationBehaviorAttribute attr in m.MethodBase.GetCustomAttributes(typeof(OperationBehaviorAttribute), false))
                    {
                        if (attr.TransactionScopeRequired == true)
                        {
                            hasTransactionScopeRequired = true;
                            break;
                        }
                    }

                    // If not, report an error:
                    if (!hasTransactionScopeRequired)
                    {
                        hasErrors = true;
                        Console.WriteLine(
                            "Method {1} on {0} must have [OperationBehavior(TransactionScopeRequired = true)]",
                            m.DeclaringType,
                            m);
                    }
                }
            }

            // Test fails if there were errors:
            if (hasErrors)
                Assert.Fail("Test failed, check Console Output for errors.");
        }
    }
}
