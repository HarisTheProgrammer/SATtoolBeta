﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ToDoSample.Service;
using ToDoSample.Testing;
using ToDoSample.Contract;

namespace ToDoSample.UnitTests
{
    /// <summary>
    /// UnitTests for ToDoCOmponentManager operations.
    /// </summary>
    [TestClass]
    public class ToDoComponentManagerTests
    {
        [TestMethod]
        public void ListAllUsersTest()
        {
            var result = ToDoComponentManager.ListAllUsers();
            
            result.AssertNotEmpty("Result should not be empty.");
        }

        [TestMethod]
        public void ListToDoItemsForUserTest()
        {
            var result = ToDoComponentManager.ListToDoItemsForUser(3);
            
            result.AssertNotEmpty("Result should not be empty.");
            result.AssertAllTrue(p => !p.IsDone, "ToDoItem should not be marked done.");
        }

        [TestMethod]
        public void ListDoneItemsForUserTest()
        {
            var result = ToDoComponentManager.ListDoneItemsForUser(1);
            
            result.AssertNotEmpty("Result should not be empty.");
            result.AssertAllTrue(p => p.IsDone, "ToDoItem should be marked done.");
        }

        [TestMethod]
        public void CreateToDoItemTest()
        {
            var nowIn8Days = DateTime.Today.AddDays(8);
            var result = ToDoComponentManager.CreateToDoItem(
                3,
                "New ToDoItem for Testing",
                nowIn8Days);

            Assert.AreEqual(3, result.Owner.Id);
            Assert.AreEqual("New ToDoItem for Testing", result.Text);
            Assert.IsTrue(result.DueDate.HasValue, "DueDate should be filled-in.");
            Assert.AreEqual(nowIn8Days, result.DueDate.Value);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidIdException))]
        public void CreateToDoItemInvalidUserIdTest()
        {
            var result = ToDoComponentManager.CreateToDoItem(
                -1,
                "New ToDoItem for Testing",
                null);
        }

        [TestMethod]
        public void MarkToDoItemDoneTest()
        {
            int todoItemId = 12;

            var before = ToDoComponentManager.GetToDoItem(todoItemId);
            Assert.IsFalse(before.IsDone, "Precondition of test failed: toDoItem should not yet be done.");

            ToDoComponentManager.MarkToDoItemDone(todoItemId);
            var after = ToDoComponentManager.GetToDoItem(todoItemId);

            Assert.AreEqual(before.Id, after.Id);
            Assert.AreEqual(before.DueDate, after.DueDate);
            Assert.IsTrue(after.IsDone, "ToDoItem should be marked done.");
        }
    }
}
