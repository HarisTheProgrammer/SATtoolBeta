﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ToDoSample.Testing
{
    /// <summary>
    /// Extension methods for assertion.
    /// </summary>
    internal static class AssertExtensions
    {
        public static void AssertNotEmpty<T>(this IEnumerable<T> items, string message)
        {
            Assert.IsTrue(items.Count() > 0, message);
        }

        public static void AssertAllTrue<T>(this IEnumerable<T> items, Predicate<T> condition, string message)
        {
            foreach (var item in items)
                Assert.IsTrue(condition(item), message);
        }
    }
}
