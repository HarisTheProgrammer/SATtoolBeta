﻿using System.Collections.Generic;
using System.Linq;

namespace TestProject
{
    class Program
    {
        static void Main(string[] args)
        {
            var timeFormat = new TimeFormatTests();
            timeFormat.Test();
        }
    }
}
