namespace ConsoleApplication1
{
	class TypeName
	{   
		static void Main(string[] args)
		{
			while(true)
				break;
		}
	}
}