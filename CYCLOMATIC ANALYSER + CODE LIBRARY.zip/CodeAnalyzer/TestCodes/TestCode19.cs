using System;
namespace ConsoleApplication1
{
	class TypeName
	{   
		static void Main(string[] args)
		{
			DateTime dateTime = new DateTime(0, 0, 0, 0, 0, 0, DateTimeKind.Local);
		}
	}
}