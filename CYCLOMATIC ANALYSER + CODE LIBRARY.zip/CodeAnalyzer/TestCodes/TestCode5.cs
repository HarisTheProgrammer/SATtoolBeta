namespace ConsoleApplication1
{
	class TypeName
	{   
		static void Main(string[] args)
		{
			for(int i = i; i < 10; i++)
			{
				int o = 1;
			}
		}
	}
}