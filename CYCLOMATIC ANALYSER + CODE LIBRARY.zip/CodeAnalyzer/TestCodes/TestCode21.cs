using System;
using System.Globalization;
namespace ConsoleApplication1
{
	class TypeName
	{   
		static void Main(string[] args)
		{
			double parsedDouble = double.Parse(""1.1"", NumberStyles.Any, CultureInfo.InvariantCulture);
		}
	}
}