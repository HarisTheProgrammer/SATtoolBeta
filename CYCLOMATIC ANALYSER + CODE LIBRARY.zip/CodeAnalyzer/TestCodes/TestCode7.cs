namespace ConsoleApplication1
{
	class TypeName
	{   
		static void Main(string[] args)
		{
			for(;;)
			{
				int o = 1;
			}
		}
	}
}