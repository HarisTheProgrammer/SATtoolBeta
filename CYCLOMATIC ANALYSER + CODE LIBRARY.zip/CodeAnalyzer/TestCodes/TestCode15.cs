namespace ConsoleApplication1
{
	class TypeName
	{   
		static void Main(string[] args)
		{
			int i = 10;
			while(i > 1)
			{
				i--;
			}
		}
	}
}