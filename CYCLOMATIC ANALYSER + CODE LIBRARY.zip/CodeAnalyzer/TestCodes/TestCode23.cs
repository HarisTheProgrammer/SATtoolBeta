using System;
using System.Globalization;
namespace ConsoleApplication1
{
	class TypeName
	{   
		static void Main(string[] args)
		{
			bool didParse = double.TryParse(""1.1"", NumberStyles.Any, CultureInfo.InvariantCulture, out double parsedDouble);
		}
	}
}