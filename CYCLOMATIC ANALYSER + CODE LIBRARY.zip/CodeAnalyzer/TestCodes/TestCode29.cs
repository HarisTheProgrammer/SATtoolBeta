namespace ConsoleApplication1
{
	[TestClass]
	public class TestClass
	{
		[TestMethod]
		public void TestMethodName()
		{
			TestResult(1);
		}
		
		private void TestResult(int k)
		{
			TestResult(k);
		}
	}
}