namespace ConsoleApplication1
{
	class TypeName
	{   
		static void Main(string[] args)
		{
			MyMethod(DateTime.Now);
		}

		private static MyMethod(DateTime dateTime)
		{
		}
	}
}