namespace ConsoleApplication1
{
	class TypeName
	{   
		static void Main(string[] args)
		{
			for(int i = i; i < 10;)
			{
				int o = 1;
				return;
			}
		}
	}
}