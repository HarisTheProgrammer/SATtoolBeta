namespace ConsoleApplication1
{
	[TestClass]
	public class TestClass
	{
		[TestMethod]
		public void TestMethodName()
		{
			int k = 1 + 2;
			j.Should().Be(3);
		}
	}
}