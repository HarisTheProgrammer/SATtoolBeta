using System;
namespace ConsoleApplication1
{
	class TypeName
	{   
		static void Main(string[] args)
		{
			var date = DateTime.Now.ToString(""mm/dd/yyyy hh:mm:ss"");
		}
	}
}