namespace ConsoleApplication1
{
	[TestClass]
	public class TestClass
	{
		[TestMethod]
		public void TestMethodName()
		{
			int k = 1 + 2;
			TestResult(k);
		}
		
		private void TestResult(int k)
		{
			k.Should().Be(1)
		}
	}
}