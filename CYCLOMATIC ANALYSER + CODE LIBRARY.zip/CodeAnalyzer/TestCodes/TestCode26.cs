namespace ConsoleApplication1
{
	[TestClass]
	public class TestClass
	{
		[TestMethod]
		public void TestMethodName()
		{
			int i = 1;
			int j = 2;
			int k = i + j;
		}
	}
}